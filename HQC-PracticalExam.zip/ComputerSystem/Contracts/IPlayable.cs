﻿namespace ComputerSystem.Contracts
{
    using System;
    using System.Linq;

    public interface IPlayable
    {
        void Play(int guessNumber);
    }
}