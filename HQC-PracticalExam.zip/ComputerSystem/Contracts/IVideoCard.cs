﻿namespace ComputerSystem.Contracts
{
    public interface IVideoCard
    {
        void Draw(string text);
    }
}